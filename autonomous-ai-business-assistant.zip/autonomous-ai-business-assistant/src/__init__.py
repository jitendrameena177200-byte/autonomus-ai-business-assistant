"""Autonomous AI Business Assistant - core package."""

__version__ = "1.0.0"
